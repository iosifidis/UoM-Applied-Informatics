﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace iis21027
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        eu.dataaccess.footballpool.ws.Info myWS = new eu.dataaccess.footballpool.ws.Info();
        protected void Page_Load(object sender, EventArgs e)
        {
            string[] results = new string[6];
            int count = 0;
            eu.dataaccess.footballpool.ws.tTeamPlayerCardRankInfo[] temp = myWS.PlayersWithCardsRanked();
            foreach (eu.dataaccess.footballpool.ws.tTeamPlayerCardRankInfo i in temp)
            {
                if (i.iRedCards > 0)
                {
                    results[count] = i.sName;
                    count++;
                    if (count > 5) break;
                }
            }

            eu.dataaccess.footballpool.ws.tPlayerName[] findteam1 = myWS.AllPlayerNames(false);
            foreach (eu.dataaccess.footballpool.ws.tPlayerName i in findteam1)
            {
                for (int k = 0; k < 6; k++)
                    if (results[k] == i.sName)
                        results[k] = results[k] + " | " + i.sCountryName;
            }
            eu.dataaccess.footballpool.ws.tPlayerName[] findteam2 = myWS.AllPlayerNames(true);
            foreach (eu.dataaccess.footballpool.ws.tPlayerName i in findteam2)
            {
                for (int k = 0; k < 6; k++)
                    if (results[k] == i.sName)
                        results[k] = results[k] + " | " + i.sCountryName ;
            }



            string output = "Παίχτες με κόκκινη κάρτα | Ομάδα τους \n";
            foreach (string i in results) 
                output = output + i +  "\n";
            TextBox1.Text = output;
        }
    }
}
