import java.util.ArrayList;

public class Registry {

	private String departmentName;
	
	// ������� ��� ArrayList �� �������� ��� ��������
	private ArrayList<Course> courses = new ArrayList<>();
	
	public Registry(String aName) {
		departmentName = aName;
	}


	public void addCourse(Course aCourse){
		
		courses.add(aCourse);
		
	}
	
	public void printDepartmentData(){
		
		System.out.println("Department Name: " + departmentName);
		System.out.println("Has the following courses: ");
		
		for(int i=0 ; i<courses.size(); i++){
			Course c = courses.get(i);
			c.printCourseDetails();
		}
	}
	
}
