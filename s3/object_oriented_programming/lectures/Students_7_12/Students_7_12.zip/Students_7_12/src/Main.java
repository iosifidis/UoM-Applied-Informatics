
public class Main {

	public static void main(String[] args) {
		
		// Εκκίνηση του παραθύρου. Δημιουργώ ανώνυμο αντικείμενο
		new StudentFrame();
		
		// Εναλλακτικά μπορώ να το δηλώσω και ως StudentFrame sf = new StudentFrame();

	}

}
