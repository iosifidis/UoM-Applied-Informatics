//Διασύνδεση: Σύνολο αφηρημένων μεθόδων

public interface Measurable {
	
	double getMeasure();

}