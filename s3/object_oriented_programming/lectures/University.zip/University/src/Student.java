
public class Student {
	
	private String name;
	private String id;
	
	//������������� ��� ������� �������, id
	public Student(String aName, String someId){
		this.name = aName;
		this.id = someId;
		
	}
	
	public Student(String aName){
		name = aName;
		id = "not defined yet";
	}
	
	public Student(){
		name = "not defined yet";
		id = "not defined yet";
	}
	
	public void printInfo(){
		
		System.out.println("Name: " + name);
		System.out.println("ID: " + id);
	}
	
	public void setName(String aName){
		
		name = aName;
	}
	
	public String getName(){
		return name;
		
	}

}
