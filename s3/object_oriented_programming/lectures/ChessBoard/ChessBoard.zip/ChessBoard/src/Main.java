
public class Main {

	public static void main(String[] args) {
		
		//Δημιουργώ ένα παράθυρο
		new GUI();

	}

}
