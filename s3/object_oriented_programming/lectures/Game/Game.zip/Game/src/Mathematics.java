
public class Mathematics {
	
	// final = κάποιος από έξω δεν επιτρέπεται να αλλάξει την τιμή της ιδιότητας
	// static για να μην υπάρχει ανάγκη να γίνει δημιουργία αντικειμένου στην main
	// public για να είναι προσβάσιμη από έξω
	public static final double PI=3.14;
	
	public static int powerOfThree(int x){
		
		return x*x*x;
	}

}
