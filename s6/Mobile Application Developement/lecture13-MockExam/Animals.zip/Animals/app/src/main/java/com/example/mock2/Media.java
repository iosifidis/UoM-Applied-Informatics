package com.example.mock2;

public class Media {
    private String image;

    public Media(String image) {
        this.image = image;
    }
    public String getImage() {
        return image;
    }

}
