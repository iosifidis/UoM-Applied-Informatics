public interface Product {


    double calculateProfit(double amount);
}
