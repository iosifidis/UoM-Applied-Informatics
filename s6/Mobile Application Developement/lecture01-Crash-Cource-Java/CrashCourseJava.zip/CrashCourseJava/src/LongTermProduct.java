
public class LongTermProduct implements Product {

	@Override
	public double calculateProfit(double a) {
		return a * 120 * 1.23;
	}

}
