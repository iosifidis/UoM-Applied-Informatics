
public interface Product {
	public double calculateProfit(double a);
}
