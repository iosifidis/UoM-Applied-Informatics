public class Eisigitis extends Melos {
	private String Extra_Info;
	public Eisigitis(String email, String password) {
		super(email, password);
		// TODO Auto-generated constructor stub
	}
	
	public Eisigitis(Melos m) {
		super(m.getEmail(),m.getPassword());
		this.Extra_Info = "";
	}

	

	/**
	 * 
	 * @param text
	 */
	public void dimiourgiseEisigisi(String text) {
		// TODO - implement ���������.dimiourgiseEisigisi
		
	}

}