
public enum PhasesOfAitisi {
	//Έχουμε βάλει με την σειρά τις φάσεις που περνάει μία αίτηση
	//Καθορίζει το τι ενέργειες μπορούν να γίνουν στην αίτηση
	PROETOIMASIA,
	ELEGXOS,
	PROTOKOLLISI,
	APORRIPSH,
	ELEGXOS_SYMFERONTWN,
	ORISMOS_EISIGITI,
	EISIGISH,
	PSHFOFORIA,
	APOFASH,
	ENHMERWSH_EREYNHTH,
	ENHMERWSH_GIA_VELTIWSEIS,
	ENHMERWSH_GIA_APODOXH
}
